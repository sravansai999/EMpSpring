package com.cg.emp.excpetion;

public class EmployeeException extends Exception{
	  
	public EmployeeException() {
	        super();
	  }
	  public EmployeeException(String message) {
		  super(message);
	  }

}
